import{_ as o}from"./role.vue_vue_type_script_setup_true_lang-BmXGp5LM.js";import"./index-BJhjvlcR.js";import"./index-Bfy7zZ-9.js";export{o as default};
