import{_ as o}from"./form.vue_vue_type_script_setup_true_lang-BtmpHPIc.js";import"./index-BJhjvlcR.js";import"./index-Bfy7zZ-9.js";export{o as default};
