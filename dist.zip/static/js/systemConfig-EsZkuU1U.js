import{a_ as t}from"./index-Bfy7zZ-9.js";const o=()=>t.request("get","/api/systemConfig/get"),r=e=>t.request("put","/api/systemConfig/update",{data:e});export{o as g,r as u};
