import{_ as m}from"./form.vue_vue_type_script_setup_true_lang-D3tzFWCt.js";import"./index-Bfy7zZ-9.js";export{m as default};
