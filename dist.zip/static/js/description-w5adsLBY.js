import{_ as m}from"./description.vue_vue_type_style_index_0_lang-DO9UmTkX.js";import"./index-Bfy7zZ-9.js";export{m as default};
