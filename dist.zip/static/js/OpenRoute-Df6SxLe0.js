import{_ as o}from"./OpenRoute.vue_vue_type_script_setup_true_lang-CgXyY561.js";import"./dock-PRaU6yTz.js";import"./index-Bfy7zZ-9.js";import"./hooks-C4C5_Ho5.js";export{o as default};
