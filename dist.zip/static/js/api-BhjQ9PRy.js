import{a_ as t}from"./index-Bfy7zZ-9.js";const a=e=>t.request("get",`/api/email/send/${e}`),i=e=>t.request("post","/api/email/sendToList",{data:e});export{i as A,a as S};
