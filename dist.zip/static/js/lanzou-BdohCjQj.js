import{_ as o}from"./lanzou.vue_vue_type_script_setup_true_lang-BtKwKKUP.js";import"./dock-PRaU6yTz.js";import"./index-Bfy7zZ-9.js";export{o as default};
